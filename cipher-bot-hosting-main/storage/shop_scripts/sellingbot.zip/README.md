# DXA Paid Zone Telegram Shop Bot

Run:
python3 -m pip install -r requirements.txt
python3 sellingbot.py
