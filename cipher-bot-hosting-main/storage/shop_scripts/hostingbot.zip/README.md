# Cipher Cloud Bot Hosting Platform

Run:
python3 -m pip install -r requirements.txt
python3 bot.py
