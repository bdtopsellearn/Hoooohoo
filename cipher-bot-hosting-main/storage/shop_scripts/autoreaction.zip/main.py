# Telegram Auto Reaction Bot (Telethon/Pyrogram)
import os, asyncio
print('Auto Reaction Bot initialized. Configure your API_ID, API_HASH, and CHANNEL_ID.')
