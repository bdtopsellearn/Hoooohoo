# Telegram Auto Reaction & View Booster Bot

Set your API credentials in .env and run:
python3 main.py
