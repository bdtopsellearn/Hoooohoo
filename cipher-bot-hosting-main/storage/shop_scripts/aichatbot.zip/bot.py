# Telegram AI ChatGPT & Gemini Bot
import os
print('Telegram AI Bot initialized. Set GEMINI_API_KEY / OPENAI_API_KEY.')
