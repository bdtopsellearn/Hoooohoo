# Telegram Gemini / OpenAI AI Assistant Bot

Run:
python3 bot.py
